import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
export default function Header() {
  const { user, logout } = useContext(AuthContext);
  return (
    <header>
      <h1>Blog</h1>
      {user ? (
        <div>
          <span>{user.username}</span>
          <button onClick={logout}>Logout</button>
        </div>
      ) : (
        <span>Guest</span>
      )}
    </header>
  );
}