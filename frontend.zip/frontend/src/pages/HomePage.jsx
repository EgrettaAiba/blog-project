import React from 'react';
export default function HomePage() {
  return <h2>Home Page - Posts will appear here</h2>;
}