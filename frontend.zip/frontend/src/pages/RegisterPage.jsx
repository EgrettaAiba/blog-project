import React from 'react';
export default function RegisterPage() { return <h2>Register Page</h2>; }